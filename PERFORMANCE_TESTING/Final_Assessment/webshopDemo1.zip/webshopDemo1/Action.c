Action()
{
    // Clean up initial connection settings
    web_set_sockets_option("SSL_VERSION", "AUTO");
    web_add_auto_header("Accept-Language", "en-US,en;q=0.9");

    
    lr_start_transaction("1_Launch");

    web_url("Categories", 
        "URL=https://demowebshop.tricentis.com/", 
        "TargetFrame=", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=", 
        "Snapshot=t25.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("1_Launch", LR_AUTO);

    lr_think_time(8);

    
    lr_start_transaction("2_register");

    // Capture the hidden verification token BEFORE making the page call
    web_reg_save_param_ex(
        "ParamName=c_token",
        "LB/IC=name=\"__RequestVerificationToken\" type=\"hidden\" value=\"",
        "RB/IC=\"",
        SEARCH_FILTERS,
        "Scope=Body",
        LAST);

    web_url("Register", 
        "URL=https://demowebshop.tricentis.com/register", 
        "TargetFrame=", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=https://demowebshop.tricentis.com/", 
        "Snapshot=t26.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("2_register", LR_AUTO);

    lr_think_time(11);

    
    lr_start_transaction("4_registerbutton");

    web_submit_data("register", 
        "Action=https://demowebshop.tricentis.com/register", 
        "Method=POST", 
        "TargetFrame=", 
        "RecContentType=text/html", 
        "Referer=https://demowebshop.tricentis.com/register", 
        "Snapshot=t27.inf", 
        "Mode=HTML", 
        "EncodeAtSign=YES", 
        ITEMDATA, 
        "Name=__RequestVerificationToken", "Value={c_token}", ENDITEM, 
        "Name=Gender", "Value=M", ENDITEM, 
        "Name=FirstName", "Value=UmeshH", ENDITEM, 
        "Name=LastName", "Value=admin", ENDITEM, 
        "Name=Email", "Value={P_Email}", ENDITEM, 
        "Name=Password", "Value=umesh@2005", ENDITEM, 
        "Name=ConfirmPassword", "Value=umesh@2005", ENDITEM, 
        "Name=register-button", "Value=Register", ENDITEM, 
        LAST);

    lr_end_transaction("4_registerbutton", LR_AUTO);

    lr_think_time(20);

    
    lr_start_transaction("5_continueR");

    web_url("Tricentis Demo Web Shop", 
        "URL=https://demowebshop.tricentis.com/", 
        "TargetFrame=", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=https://demowebshop.tricentis.com/registerresult/1", 
        "Snapshot=t28.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("5_continueR", LR_AUTO);

    lr_think_time(21);

    
    lr_start_transaction("6_choose");

    web_url("14.1-inch Laptop", 
        "URL=https://demowebshop.tricentis.com/141-inch-laptop", 
        "TargetFrame=", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=https://demowebshop.tricentis.com/", 
        "Snapshot=t29.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("6_choose", LR_AUTO);

    
    lr_start_transaction("7_addtocart");

    web_submit_data("1", 
        "Action=https://demowebshop.tricentis.com/addproducttocart/details/31/1", 
        "Method=POST", 
        "TargetFrame=", 
        "RecContentType=application/json", 
        "Referer=https://demowebshop.tricentis.com/141-inch-laptop", 
        "Snapshot=t30.inf", 
        "Mode=HTML", 
        ITEMDATA, 
        "Name=addtocart_31.EnteredQuantity", "Value=1", ENDITEM, 
        LAST);

    lr_end_transaction("7_addtocart", LR_AUTO);

    lr_think_time(18);

    
    lr_start_transaction("8_shippingcart");

    // Capture the cart item quantity field name (e.g., itemquantity7121419)
    web_reg_save_param_ex(
        "ParamName=c_CartItemName",
        "LB/IC=name=\"itemquantity",
        "RB/IC=\"",
        SEARCH_FILTERS,
        "Scope=Body",
        LAST);

    web_url("cart", 
        "URL=https://demowebshop.tricentis.com/cart", 
        "TargetFrame=", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=https://demowebshop.tricentis.com/141-inch-laptop", 
        "Snapshot=t31.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("8_shippingcart", LR_AUTO);

   
    lr_start_transaction("9_checkout");

    web_url("getstatesbycountryid", 
        "URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true&_=1790845438637", 
        "TargetFrame=", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://demowebshop.tricentis.com/cart", 
        "Snapshot=t32.inf", 
        "Mode=HTML", 
        LAST);

    web_submit_data("cart_2", 
        "Action=https://demowebshop.tricentis.com/cart", 
        "Method=POST", 
        "EncType=multipart/form-data", 
        "TargetFrame=", 
        "RecContentType=text/html", 
        "Referer=https://demowebshop.tricentis.com/cart", 
        "Snapshot=t33.inf", 
        "Mode=HTML", 
        ITEMDATA, 
        "Name=itemquantity{c_CartItemName}", "Value=1", ENDITEM, 
        "Name=discountcouponcode", "Value=", ENDITEM, 
        "Name=giftcardcouponcode", "Value=", ENDITEM, 
        "Name=CountryId", "Value=41", ENDITEM, 
        "Name=StateProvinceId", "Value=0", ENDITEM, 
        "Name=ZipPostalCode", "Value=", ENDITEM, 
        "Name=termsofservice", "Value=on", ENDITEM, 
        "Name=checkout", "Value=checkout", ENDITEM, 
        LAST);

    lr_end_transaction("9_checkout", LR_AUTO);

    lr_think_time(22);

    
    lr_start_transaction("10_billing");

    web_url("getstatesbycountryid_2", 
        "URL=https://demowebshop.tricentis.com/country/getstatesbycountryid?countryId=41&addEmptyStateIfRequired=true&_=1790845468082", 
        "TargetFrame=", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://demowebshop.tricentis.com/onepagecheckout", 
        "Snapshot=t34.inf", 
        "Mode=HTML", 
        LAST);

    lr_think_time(34);

    web_submit_data("OpcSaveBilling", 
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveBilling/", 
        "Method=POST", 
        "TargetFrame=", 
        "RecContentType=application/json", 
        "Referer=https://demowebshop.tricentis.com/onepagecheckout", 
        "Snapshot=t35.inf", 
        "Mode=HTML", 
        "EncodeAtSign=YES", 
        ITEMDATA, 
        "Name=BillingNewAddress.Id", "Value=0", ENDITEM, 
        "Name=BillingNewAddress.FirstName", "Value=UmeshH", ENDITEM, 
        "Name=BillingNewAddress.LastName", "Value=admin", ENDITEM, 
        "Name=BillingNewAddress.Email", "Value={P_Email}", ENDITEM, 
        "Name=BillingNewAddress.Company", "Value=", ENDITEM, 
        "Name=BillingNewAddress.CountryId", "Value=41", ENDITEM, 
        "Name=BillingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
        "Name=BillingNewAddress.City", "Value=Bengal", ENDITEM, 
        "Name=BillingNewAddress.Address1", "Value=gnagar", ENDITEM, 
        "Name=BillingNewAddress.Address2", "Value=new street", ENDITEM, 
        "Name=BillingNewAddress.ZipPostalCode", "Value=543101", ENDITEM, 
        "Name=BillingNewAddress.PhoneNumber", "Value=6300904567", ENDITEM, 
        "Name=BillingNewAddress.FaxNumber", "Value=", ENDITEM, 
        LAST);

    lr_end_transaction("10_billing", LR_AUTO);

    
    lr_start_transaction("11_shippingaddress");

    web_submit_data("OpcSaveShipping", 
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveShipping/", 
        "Method=POST", 
        "TargetFrame=", 
        "RecContentType=application/json", 
        "Referer=https://demowebshop.tricentis.com/onepagecheckout", 
        "Snapshot=t36.inf", 
        "Mode=HTML", 
        "EncodeAtSign=YES", 
        ITEMDATA, 
        "Name=shipping_address_id", "Value=0", ENDITEM, 
        "Name=ShippingNewAddress.Id", "Value=0", ENDITEM, 
        "Name=ShippingNewAddress.FirstName", "Value=UmeshH", ENDITEM, 
        "Name=ShippingNewAddress.LastName", "Value=admin", ENDITEM, 
        "Name=ShippingNewAddress.Email", "Value={P_Email}", ENDITEM, 
        "Name=ShippingNewAddress.Company", "Value=", ENDITEM, 
        "Name=ShippingNewAddress.CountryId", "Value=0", ENDITEM, 
        "Name=ShippingNewAddress.StateProvinceId", "Value=0", ENDITEM, 
        "Name=ShippingNewAddress.City", "Value=", ENDITEM, 
        "Name=ShippingNewAddress.Address1", "Value=", ENDITEM, 
        "Name=ShippingNewAddress.Address2", "Value=", ENDITEM, 
        "Name=ShippingNewAddress.ZipPostalCode", "Value=", ENDITEM, 
        "Name=ShippingNewAddress.PhoneNumber", "Value=", ENDITEM, 
        "Name=ShippingNewAddress.FaxNumber", "Value=", ENDITEM, 
        "Name=PickUpInStore", "Value=false", ENDITEM, 
        LAST);

    lr_end_transaction("11_shippingaddress", LR_AUTO);

    lr_think_time(16);

    
    lr_start_transaction("12_shippingmethod");

    web_submit_data("OpcSaveShippingMethod", 
        "Action=https://demowebshop.tricentis.com/checkout/OpcSaveShippingMethod/", 
        "Method=POST", 
        "TargetFrame=", 
        "RecContentType=application/json", 
        "Referer=https://demowebshop.tricentis.com/onepagecheckout", 
        "Snapshot=t37.inf", 
        "Mode=HTML", 
        ITEMDATA, 
        "Name=shippingoption", "Value=Ground___Shipping.FixedRate", ENDITEM, 
        LAST);

    lr_end_transaction("12_shippingmethod", LR_AUTO);

    lr_think_time(17);

   
    lr_start_transaction("14_paymentmethod");

    web_submit_data("OpcSavePaymentMethod", 
        "Action=https://demowebshop.tricentis.com/checkout/OpcSavePaymentMethod/", 
        "Method=POST", 
        "TargetFrame=", 
        "RecContentType=application/json", 
        "Referer=https://demowebshop.tricentis.com/onepagecheckout", 
        "Snapshot=t38.inf", 
        "Mode=HTML", 
        ITEMDATA, 
        "Name=paymentmethod", "Value=Payments.CashOnDelivery", ENDITEM, 
        LAST);

    lr_end_transaction("14_paymentmethod", LR_AUTO);

    lr_think_time(23);

   
    lr_start_transaction("15_paymentinfo");

    web_custom_request("OpcSavePaymentInfo", 
        "URL=https://demowebshop.tricentis.com/checkout/OpcSavePaymentInfo/", 
        "Method=POST", 
        "TargetFrame=", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://demowebshop.tricentis.com/onepagecheckout", 
        "Snapshot=t39.inf", 
        "Mode=HTML", 
        "EncType=", 
        LAST);

    lr_end_transaction("15_paymentinfo", LR_AUTO);

    lr_think_time(21);

    
    lr_start_transaction("16_confirm");

    web_custom_request("OpcConfirmOrder", 
        "URL=https://demowebshop.tricentis.com/checkout/OpcConfirmOrder/", 
        "Method=POST", 
        "TargetFrame=", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://demowebshop.tricentis.com/onepagecheckout", 
        "Snapshot=t40.inf", 
        "Mode=HTML", 
        "EncType=", 
        LAST);

    web_url("completed", 
        "URL=https://demowebshop.tricentis.com/checkout/completed/", 
        "TargetFrame=", 
        "Resource=0", 
        "RecContentType=text/html", 
        "Referer=https://demowebshop.tricentis.com/onepagecheckout", 
        "Snapshot=t41.inf", 
        "Mode=HTML", 
        LAST);

    lr_end_transaction("16_confirm", LR_AUTO);

    return 0;
}